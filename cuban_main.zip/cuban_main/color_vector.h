class ColorVector {
  public:
    int r;
    int g;
    int b;
    int a;
    
    ColorVector(int red, int green, int blue, int alpha) {
      r = red;
      g = green;
      b = blue;
      a = alpha;
    }
//    might put getters here later...
};
